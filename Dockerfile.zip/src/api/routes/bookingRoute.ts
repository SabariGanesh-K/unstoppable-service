// const express = require('express')
// import { type Container } from "inversify";
// import bookingController from "../controllers/bookingController";

// export const bookingRouter = ()=>{
//     const router = express.Router()
//     router.post("/:n",bookingController)
//     return router;
// }